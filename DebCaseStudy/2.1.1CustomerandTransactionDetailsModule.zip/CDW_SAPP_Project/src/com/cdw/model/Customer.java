package com.cdw.model;

public class Customer {
	private String creditCardNo, 
	state, 
	city, 
	country, 
	zip, 
	email, 
	firstName,
	middleName,
	lastName,
	aptNo,
	streetName;
	private int ssn, phone;
	
	// Constructors - Default
	public Customer(){}
	
	// Customers Parameterized
	public Customer(
			String firstName,
			String middleName,
			String lastName,
			int ssn,
			String creditCardNo, 
			String aptNo,
			String streetName,
			String city,
			String state,
			String country,
			String zip,
			int phone,
			String email) {
		this.creditCardNo = creditCardNo;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.aptNo = aptNo;
		this.streetName = streetName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.email = email;
		this.ssn = ssn;
		this.phone = phone;
		
	}
	// Getters and Setters------------------------------------------------
	public String getCreditCardNo() {
		return creditCardNo;
	}
	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAptNo() {
		return aptNo;
	}
	public void setAptNo(String aptNo) {
		this.aptNo = aptNo;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public int getSsn() {
		return ssn;
	}
	public void setSsn(int ssn) {
		this.ssn = ssn;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	// toString override---------------------------------------------------
//	public String toString() {
//		String out = firstName + "," + middleName + "," + lastName +
//					"," + ssn + "," + country + "," + streetName + "," +
//					aptNo + "," + city + "," + state + "," + zip + "," + 
//					phone + "," + email + "," + creditCardNo;
//		return out;
//	}
	public String toString() {
		String out = "First Name: " + firstName + 
					"\r\nMiddle Name: " + middleName + 
					"\r\nLast Name: " + lastName + 
					"\r\nSocial Security Number: " + ssn + 
					"\r\nCountry: " + country + 
					"\r\nStreet Name: " + streetName + 
					"\r\nApartment Number: " + aptNo + 
					"\r\nCity: " + city +
					"\r\nState: " + state + 
					"\r\nZipcode: " + zip +
					"\r\nPhone Number: " + phone + 
					"\r\nE-mail Address: " + email +
					"\r\nCredit Card Number: " + creditCardNo;
		return out;
	}
	// --------------------------------------------------------------------
}
