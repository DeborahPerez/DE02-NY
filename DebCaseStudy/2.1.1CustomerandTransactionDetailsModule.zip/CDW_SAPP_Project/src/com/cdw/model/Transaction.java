package com.cdw.model;

public class Transaction {
	private int transaction_id,
	day,
	month,
	year,
	ssn,
	branchCode;
	private String creditCardNo,
	transactionType;
	private double transactionValue;
	
	public Transaction(){}
	
	// Transaction parameterized
	public Transaction (
			int transaction_id,
			int day,
			int month,
			int year,
			String creditCardNo,
			int ssn,
			int branchCode,
			String transactionType,
			double transactionValue
			){
			this.transaction_id = transaction_id;
			this.day = day;
			this.month = month;
			this.year = year;
			this.creditCardNo = creditCardNo;
			this.ssn = ssn;
			this.branchCode = branchCode;
			this.transactionType = transactionType;
			this.transactionValue = transactionValue;
	}
	// Getters and Setters------------------------------------------------
	public int getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getTransactionValue() {
		return transactionValue;
	}

	public void setTransactionValue(double transactionValue) {
		this.transactionValue = transactionValue;
	};
	// toString override---------------------------------------------------
	public String toString() {
		String out = transaction_id + "," +
		day + "," + month + "," + year + 
		"," + creditCardNo + 
		"," + ssn + "," + branchCode +
		"," + transactionType +
		"," + transactionValue;
		return out;
	}
	// --------------------------------------------------------------------
//	public String toString() {
//	String out = "Transaction ID: " + transaction_id + "\r\nDay: " +
//	day + "\r\nMonth: " + month + "\r\nYear: " + year + 
//	"\r\nCredit Card Number: " + creditCardNo + 
//	"\r\nCustomer SSN: " + ssn + "\r\nBranch Code: " + branchCode +
//	"\r\nTransaction Type: " + transactionType +
//	"\r\nTransaction Value: " + transactionValue;
//	return out;
//}
	}
