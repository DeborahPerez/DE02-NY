package com.cdw.exceptions;

public class NotInt1Through7 extends Exception{
	public NotInt1Through7() {
		super("Valid input is an integer between 1 and 7, only!");
	}
}
