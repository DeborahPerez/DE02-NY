package com.cdw.exceptions;

public class NotValidSSN extends Exception{
	public NotValidSSN () {
		System.out.println("This is not a valid social security number!\r\n" +
							"It must be an integer with 9 digits!");
	}
 }
