package com.cdw.dao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cdw.model.Customer;
import com.cdw.model.Transaction;
import com.cdw.resources.Queries;

public class TransactionDAO extends AbstractDAO{
	String[] tParameters = {
		"TRANSACTION_ID",
		"DAY",
		"MONTH",
		"YEAR",
		"CREDIT_CARD_NO",
		"CUST_SSN",
		"BRANCH_CODE",
		"TRANSACTION_TYPE",
		"TRANSACTION_VALUE"
	};
	
	String[] transFieldList = {
			"transaction_id", 
			"day", 
			"month", 
			"year", 
			"ssn", 
			"branchCode", 
			"creditCardNo", 
			"transactionType", 
			"transactionValue"
	};
//---------------------------------------------------------------------------------
// Display transactions made by customers for given zipcode, month and year--------
	public List<Transaction> getTransaction(String zipCode, int month, int year) {
		List<Transaction> transactionList = new ArrayList <Transaction>();
		Transaction transaction = null;
		establishConnection();
		String query = Queries.TRANSACTION_BY_ZIP_M_Y;
		try {
			state = conn.prepareStatement(query);
			state.setString(1, zipCode);
			state.setInt(2, month);
			state.setInt(3, year);
			
			result = state.executeQuery();
			while(result.next()) {
				// Initialize new customer object in order
				transaction = new Transaction(
							result.getInt(tParameters[0]),
							result.getInt(tParameters[1]),
							result.getInt(tParameters[2]),
							result.getInt(tParameters[3]),
							result.getString(tParameters[4]),
							result.getInt(tParameters[5]),
							result.getInt(tParameters[6]),
							result.getString(tParameters[7]),
							result.getDouble(tParameters[8])
							);
				transactionList.add(transaction);
			}
		} catch (SQLException e){
			e.printStackTrace();
		}
		return transactionList;
	}
//-----------------------------------------------------------------------------------
// -To display the number and total values of transactions for a given type. 
	public List<Integer> getTotalByType(String transactionType) {
		int totalCount = 0;
		int totalSum = 0;
		List<Integer> countList = new ArrayList<Integer>();
		establishConnection();
		String query = Queries.TOTAL_BY_TYPE;
		
		try {
			state = conn.prepareStatement(query);
			state.setString(1, transactionType);
			
			result = state.executeQuery();
			if (result.next()) {
				totalSum = result.getInt(1);
				totalCount = result.getInt(2);
				countList.add(totalSum);
				countList.add(totalCount);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return countList;
	}
//-----------------------------------------------------------------------------------
	public List<Integer> getTotalByState(String branchState) {
		int totalCount = 0;
		int totalSum = 0;
		List<Integer> countList = new ArrayList<Integer>();
		establishConnection();
		String query = Queries.TOTAL_BY_STATE;
		
		try {
			state = conn.prepareStatement(query);
			state.setString(1, branchState);
			
			result = state.executeQuery();
			if (result.next()) {
				totalSum = result.getInt(1);
				totalCount = result.getInt(2);
				countList.add(totalSum);
				countList.add(totalCount);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
//		System.out.println("Total Count: " + totalCount);
//		System.out.println("Sum of Values:  " + totalSum);
		return countList;
		
	}
//-------------------------------------------------------------------------------------
}
