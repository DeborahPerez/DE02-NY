package com.cdw.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cdw.model.Customer;
import com.cdw.model.Transaction;
import com.cdw.resources.Queries;

public class CustomerDAO extends AbstractDAO{
	// 2.1.2 Customer Details Module
	// 2.1.2 Customer Details
	// Credit Card System Req-2.1.2
	// Functional Requirements
// Parameters String-------------------------------------------------------------
	String [] cParameters = {
			"FIRST_NAME",
			"MIDDLE_NAME",
			"LAST_NAME",
			"SSN",
			"CREDIT_CARD_NO",
			"APT_NO",
			"STREET_NAME",
			"CUST_CITY",
			"CUST_STATE",
			"CUST_COUNTRY",
			"CUST_ZIP",
			"CUST_PHONE",
			"CUST_EMAIL"	
	};
	String[] tParameters = {
			"TRANSACTION_ID",
			"DAY",
			"MONTH",
			"YEAR",
			"CREDIT_CARD_NO",
			"CUST_SSN",
			"BRANCH_CODE",
			"TRANSACTION_TYPE",
			"TRANSACTION_VALUE"
		};
//---------------------------------------------------------------------------------
// 1. To check the existing account details of a customer------------------------
	public Customer getCustomerBySSN(int ssn) {
		Customer customer = null;
		establishConnection();
		String query = Queries.GET_CUSTOMER_BY_SSN;
		// try catch for exception for prepared statement
		// initialize statement object with conn.prepareStatement
		try {
			state = conn.prepareStatement(query);
			//set value of ? that's in the query
			state.setInt(1, ssn);
			
			// results
			result = state.executeQuery();
			if(result.next()) {
				// Initialize new customer object in order
				customer = new Customer(
							result.getString(cParameters[0]),
							result.getString(cParameters[1]),
							result.getString(cParameters[2]),
							result.getInt(cParameters[3]),
							result.getString(cParameters[4]),
							result.getString(cParameters[5]),
							result.getString(cParameters[6]),
							result.getString(cParameters[7]),
							result.getString(cParameters[8]),
							result.getString(cParameters[9]),
							result.getString(cParameters[10]),
							result.getInt(cParameters[11]),
							result.getString(cParameters[12])
						);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;	
	}
//---------------------------------------------------------------------------------
// 2. To modify the existing account details of a customer-------------------------
	public Customer modifyCustomerStringDetail(String detail, int ssn, String query) {
		
		Customer customer = null;
		establishConnection();
		// Choose a string query as per the detail you would like to change--------
		//String query = Queries.MODIFY_FIRST_NAME; //FIRST_NAME
		try {
			state = conn.prepareStatement(query);
			//set value of ? that's in the query
			state.setString(1, detail);
			state.setInt(2, ssn);
			state.executeUpdate();
			
			customer = new Customer();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Call customer object with new details------------------------------------
		customer = getCustomerBySSN(ssn);
		return customer;
	}
//----------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------
	public List<Transaction> monthlyBill(String ccNumber, int month, int year) {
		List<Transaction> transactionList = new ArrayList <Transaction>();
		Transaction transaction = null;
		establishConnection();
		String query = Queries.GET_MONTHLY_BILL;
		try {
			state = conn.prepareStatement(query);
			state.setString(1, ccNumber);
			state.setInt(2, month);
			state.setInt(3, year);
			
			result = state.executeQuery();
			while(result.next()) {
				// Initialize new transaction object in order
				transaction = new Transaction(
							result.getInt(tParameters[0]),
							result.getInt(tParameters[1]),
							result.getInt(tParameters[2]),
							result.getInt(tParameters[3]),
							result.getString(tParameters[4]),
							result.getInt(tParameters[5]),
							result.getInt(tParameters[6]),
							result.getString(tParameters[7]),
							result.getDouble(tParameters[8])
							);
				transactionList.add(transaction);
			}
		} catch (SQLException e){
			e.printStackTrace();
		}
		return transactionList;
		
	}
// -----------------------------------------------------------------------------------
	public List<Transaction> transBetweenDates(int ssn, String date1, String date2) throws ParseException {
		List<Transaction> transactionList = new ArrayList <Transaction>();
		Transaction transaction = null;
		establishConnection();
		String query = Queries.TRANS_BETWEEN_DATES;
		try {
			// Set dates to sql format
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date formatDate1 = sdf.parse(date1);
			Date formatDate2 = sdf.parse(date2);
			java.sql.Date sqlDate1 = new java.sql.Date(formatDate1.getTime());
			java.sql.Date sqlDate2 = new java.sql.Date(formatDate2.getTime());
			
			state = conn.prepareStatement(query);
			state.setInt(1, ssn);
			state.setDate(2, sqlDate1);
			state.setDate(3, sqlDate2);
			
			result = state.executeQuery();
			while (result.next()) {
				transaction = new Transaction(
						result.getInt(tParameters[0]),
						result.getInt(tParameters[1]),
						result.getInt(tParameters[2]),
						result.getInt(tParameters[3]),
						result.getString(tParameters[4]),
						result.getInt(tParameters[5]),
						result.getInt(tParameters[6]),
						result.getString(tParameters[7]),
						result.getDouble(tParameters[8])
						);
			transactionList.add(transaction);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transactionList;
	}
// -----------------------------------------------------------------------------------
}