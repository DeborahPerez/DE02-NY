package com.cdw.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public abstract class AbstractDAO {
	// protected so only working within the package
	protected Connection conn = null;
	protected PreparedStatement state = null;
	protected ResultSet result = null;
	
	protected void establishConnection() {
		// Make a new Properties object
		Properties prop = new Properties();
		
		// Derives where the db.properties file exists
		try {
			FileInputStream fs = new FileInputStream(
					this.getClass().getClassLoader()
					.getResource("com/cdw/resources/db.properties")
					.getFile()
					);		
			
			// Get values from db.properties
			// Initialize variables to store property keys
			prop.load(fs);
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String password = prop.getProperty("password");
			
			// Loads driver and knows to interpret it as a mysql driver
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
			
			// catches any type of exception that happens
		} catch (Exception e) {
			// If fails does not want to have instance of properties made
			e.printStackTrace();
		}
	}
}