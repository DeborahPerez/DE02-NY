package com.cdw.runner;

import java.text.ParseException;
import java.util.Scanner;

import com.cdw.exceptions.NotInt1Through7;
import com.cdw.exceptions.NotValidSSN;

public class Main {

	public static void main(String[] args) throws ParseException, NotInt1Through7 {
		// Call runner
		Runner mRunner = new Runner();
		Scanner scan = new Scanner(System.in);
		String menu;
		int choice = 0;
		
		// menu loop----------------------------------------------------------------
		do {
			try {
				// Call intro screen and save choice from intro
				choice = runIntro();
			} catch (Exception e) {
				newLine();
				notBTWN1And7();
				newLine();
				choice = runIntro();
			}
			// end program if 0 entered
			if (choice==0) {
				newLine();
				System.out.println("End of Program");
				System.out.println("Goodbye!");
			}
			else if (choice!=0 && choice >= 1 && choice <= 7) {
				// switch cases------------------------------------------------------
				switch (choice)
				{
					case 1 : // 1. Check existing account details of a customer by ssn
						mRunner.runGetCustomerBySSN();
						break;
						
					case 2: // 2. Modify existing account details of a customer
						mRunner.runModifyCustomer();
						break;
						
					case 3: // 3. Generate monthly bill
						// Format to be in table format
						mRunner.runMonthlyBill();
						break;
						
					case 4: // 4. Display transactions by zipcode, month, year
						// Format to be in table format
						mRunner.runGetTransaction();
						break;
						
					case 5: // 5. Display number and total values for type
						mRunner.runGetTotalByType();
						break;
						
					case 6: // 6. Display number and total values for branches by state
						mRunner.runGetTotalByState();
						break;
						
					case 7: // 7. Display transactions between two dates
						mRunner.runTransBetweenDates();
						break;	
				}
			}
			else {
				newLine();
				notBTWN1And7();
				}
	} while (choice!=0);
	}
// ----------------------------------------------------------------------------------
	private static int runIntro() {
		// Scanner and user input details
		Scanner scan = new Scanner(System.in);
		//
		System.out.println();
		bLine();
		bLine();
		System.out.println("***********Welcome to the Transaction and Customer Details " + 
							"Module***********");
		bLine();
		bLine();
		System.out.println();
		System.out.println("What would you like to do? (Please choose a number)");
		System.out.println("Enter 0 to exit the program");
		System.out.println();
		System.out.println(
		"1) Check the existing account details of a customer.\r\n" +
		"2) Modify the existing account details of a customer.\r\n" +
		"3) Generate monthly bill for a credit card number for a given month\r\n" +
		"   and year.\r\n" +
		"4) Display the transactions made by customers\r\n " +
		"  living in a given zipcode for a given month and year.\r\n" +
		"5) Display the number and total values of transactions for a given type.\r\n" +
		"6) Display the number and total values of transactions for branches\r\n " +
		"  in a given state.\r\n" +
		"7) Display the transactions made by a customer between\r\n" +
		"   two dates. Order by year, month, and day in descending order.\r\n");
		dLine();
		System.out.print("Your choice: ");
		
		if (scan.hasNextInt()) {
			int choice = scan.nextInt();
			scan.nextLine();
			return choice;
		}
		else {
			return 10;
		}
	}
// -New Line-------------------------------------------------------------------------
	private static void newLine() {
		System.out.println();
	}
// -Dotted Line----------------------------------------------------------------------
	public static void dLine() {
		System.out.println("--------------------------------------------------------------" + 
							"--------------");
	}
// -Asterisk Line--------------------------------------------------------------------
	public static void bLine() {
		System.out.println("*************************************************************" + 
							"***************");
	}
	public static void errorLine() {
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + 
							"!!!!!!!!!!!!!!");
	}
	private static void notBTWN1And7() {
		errorLine();
		System.out.println("Please enter a valid number from 1 through 7!");
		errorLine();
	}
}	
