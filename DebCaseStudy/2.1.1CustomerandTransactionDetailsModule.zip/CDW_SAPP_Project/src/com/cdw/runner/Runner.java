package com.cdw.runner;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.*;

import sun.security.util.Length;

import com.cdw.dao.CustomerDAO;
import com.cdw.dao.TransactionDAO;
import com.cdw.exceptions.NotValidSSN;
import com.cdw.model.Customer;
import com.cdw.model.Transaction;
import com.cdw.resources.Queries;

public class Runner {
// Case methods---------------------------------------------------------------------
	Scanner scan = new Scanner(System.in);
	// -1-Customer Details----------------------------------------------------------
	void runGetCustomerBySSN(){
		// Header
		newLine();
		newLine();
		bLine();
		System.out.println("******************Welcome to the Customer Details " + 
							"Section*******************");
		bLine();
		newLine();
		System.out.println("Please enter a customer's social security Number(SSN) " + 
							"to see details ");
		System.out.print("SSN: ");
		// User input
		if (scan.hasNextInt()) {
			int ssn = scan.nextInt();
			scan.nextLine();
			try {
				Customer cust;
				CustomerDAO cDAO = new CustomerDAO();
				cust = cDAO.getCustomerBySSN(ssn);
				newLine();
				if (String.valueOf(ssn).length() == 9) {
					System.out.println("Here are the customer details: ");
					System.out.println(cust.toString());
					dLine();
				
					// Ask to export to file
					System.out.print("Would you like to export the data to a file? (Y/N)");
					String decision = scan.next();
					decision.toLowerCase();
					if (decision.equals("y")) {
						exportCustObj2TxtFile(cust);
					}
				}
				else {
					errorSSN();
					newLine();
				}
			} catch (Exception e) {
				errorString();
				newLine();
			}
		}
		else {
			errorString();
			newLine();
			scan.nextLine();
		}
	}
	// -2-Modify Customer Details----------------------------------------------------
	void runModifyCustomer() {
		// Header
		newLine();
		newLine();
		bLine();		
		System.out.println("************Welcome to the Customer Detail " + 
							"Modification Section*************");
		bLine();
		newLine();
		System.out.println("Please enter a customer's social security number(SSN) " + 
							"to see details: ");
		System.out.print("SSN: ");
		
		// If user inputs a number for ssn
		if (scan.hasNextInt()) {
			int ssn = scan.nextInt(); //assign input to ssn
			scan.nextLine();
			try { 
				Customer cust;
				CustomerDAO cDAO = new CustomerDAO();
				cust = cDAO.getCustomerBySSN(ssn);
				newLine();
				// if the ssn is valid length of 9
				if (String.valueOf(ssn).length() == 9) {
					System.out.println("Here are the customer details: ");
					System.out.println();
					System.out.println(cust.toString());
					dLine();
					// for menu choice
					int choice = 0;
					do { //loop
						System.out.println();
						System.out.println("Which detail would you like to change about the customer? ");
						System.out.println("Enter 0 to exit this section");
						System.out.println("1)  First Name\r\n2)  Middle Name\r\n3)  Last Name\r\n" +
							"4)  Apt No\r\n" + 
							"5)  Customer's Street\r\n6)  Customer's City\r\n" +
							"7)  Customer's State\r\n8)  Customer's Zipcode\r\n" +
							"9)  Customer's Phone Number\r\n" + 
							"10) Customer's E-mail Address\r\n" +
							"11) Customer's Country\r\n");
						dLine();
						System.out.print("Your choice: ");
						choice = scan.nextInt();
						scan.nextLine();
					
						// Query choice
						String dType = null;
						String query = null;
						switch(choice) {
							case 1:
								query = Queries.MODIFY_FIRST_NAME;
								dType = "First Name";
								break;
							case 2:
								query = Queries.MODIFY_MIDDLE_NAME;
								dType = "Middle Name";
								break;
							case 3:
								query = Queries.MODIFY_LAST_NAME;
								dType = "Last Name";
								break;
							case 4:
								query = Queries.MODIFY_APT_NO;
								dType = "Apartment Number";
								break;
							case 5:
								query = Queries.MODIFY_STREET_NAME;
								dType = "Street Name";
								break;
							case 6:
								query = Queries.MODIFY_CUST_CITY;
								dType = "City";
								break;
							case 7:
								query = Queries.MODIFY_CUST_STATE;
								dType = "State";
								break;
							case 8:
								query = Queries.MODIFY_CUST_ZIP;
								dType = "Zipcode";
								break;
							case 9:
								query = Queries.MODIFY_CUST_PHONE;
								dType = "Phone Number";
								break;
							case 10:
								query = Queries.MODIFY_CUST_EMAIL;
								dType = "E-mail address";
								break;
							case 11:
								query = Queries.MODIFY_CUST_COUNTRY;
								dType = "Country";
								break;
						}
					
						// Check if input needs to be an integer or String
						if (choice!=0 && choice >= 1 && choice <= 11) {
							System.out.println();
							dLine();
							System.out.print("Please enter the new detail you'd like to input: ");
							String detail = scan.nextLine();
							
							// Confirm update
							newLine();
							dLine();
							System.out.print("Are you sure you would like to update the " + 
												dType + " to " + detail + " ? (Y/N)");
							String updateChoice = scan.next();
							updateChoice.toLowerCase();
							if (updateChoice.equals("y")) {
								cust = cDAO.modifyCustomerStringDetail(detail, ssn, query);
								newLine();
								System.out.println("Here are the modified customer details: ");
								newLine();
								System.out.println(cust.toString());
								dLine();
							}
						}
						// Invalid input out of range
						else {
							outOfRange();
							newLine();
						}
				} while (choice!=0);
				}
				else {
					errorSSN();
					newLine();
				}
				//
			} catch (Exception e) {
				errorSSN();
				newLine();
				scan.nextLine();
			}
		}
		else {
			errorString();
			newLine();
			scan.nextLine();
		}
			}
	// -3-Monthly Bill----------------------------------------------------------------
	void runMonthlyBill() {
		// Intro
		newLine();
		bLine();
		System.out.println("********************Welcome to the Monthly Bill " + 
							"Section*********************");
		bLine();
		newLine();
		
		// User input
		System.out.print("Please enter a 16 digit Credit Card Number: ");
		String ccn = scan.next();
		if (String.valueOf(ccn).length() == 16) {
			System.out.print("Please enter a Month: ");
			if (scan.hasNextInt()) {
				int month = scan.nextInt(); //assign input to ssn
				scan.nextLine();
				if (String.valueOf(month).length() == 2) {
					System.out.print("Please enter a Year: ");
					if (scan.hasNextInt()) {
						int year = scan.nextInt();
						scan.nextLine();
						if (String.valueOf(year).length() == 4) {
							dLine();
							
							// Query transaction
							List<Transaction> bill;
							CustomerDAO cDAO = new CustomerDAO();
							bill = cDAO.monthlyBill(ccn, month, year);
							newLine();
							System.out.println("Here is the Bill for Credit Card Number " + ccn + 
												" for the " + month + " month in\r\nthe year " + year);
							// Table Format for Bill
							billFormat(bill);
							
							// If empty
							System.out.println("If your query is empty you should try again" + 
												" with different parameters!");
							
							// Ask to export to file
							System.out.print("Would you like to export the data to a file? (Y/N)");
							String decision = scan.next();
							decision.toLowerCase();
							if (decision.equals("y")) {
								exportToTxtFile(bill);
							}
							dLine();
							newLine();
						}
						else {
							scan.nextLine();
							newLine();
							not4DInt();
							endSection();
						}
						
					}
					else {
						scan.nextLine();
						newLine();
						errorString();
						endSection();
					}
						
				}
				else {
					scan.nextLine();
					newLine();
					not2DInt();
					endSection();
				}
			}
			else {
				scan.nextLine();
				newLine();
				errorString();
				endSection();
			}
		}
		else {
			scan.nextLine();
			newLine();
			errorCCN();
			endSection();
		}
	}
	// -4-Transactions for zipcodes-----------------------------------------------------
	void runGetTransaction() {
		// Intro
		newLine();
		bLine();
		System.out.println("***************Welcome to the Transactions By Zipcode " + 
							"Section***************");
		bLine();
		newLine();
		
		// User Input
		try {
			System.out.print("Please enter a zipcode: ");
			String zip = scan.next();
			scan.nextLine();
			System.out.print("Please enter a month: ");
			int month = scan.nextInt();
			scan.nextLine();
			System.out.print("Please enter a year: ");
			int year = scan.nextInt();
			scan.nextLine();
			dLine();
			
			// Display Transactions
			List<Transaction> queryList;
			TransactionDAO tDAO = new TransactionDAO();
			queryList = tDAO.getTransaction(zip, month, year);
			newLine();
			System.out.println("Here are the transactions for the zipcode " + zip + 
					            " in month " + month + " of the year " + year);
			newLine();
			transFormat(queryList);
			newLine();
			
			// Ask to export to file
			System.out.print("Would you like to export the data to a file? (Y/N)");
			String decision = scan.next();
			dLine();
			decision.toLowerCase();
			if (decision.equals("y")) {
				exportToTxtFile(queryList);
			}
			}
		catch (Exception e){
			errorString();
		}
	}
	// -5-Total Count and Total Values for Transaction Type-------------------------------
	public void runGetTotalByType() {
		// intro
			newLine();
			bLine();
			System.out.println("*********Welcome to the Total Count and Total Values " + 
								"by Type Section********");
			bLine();
			newLine();
			System.out.println("These are the following transaction types");
			System.out.println("1) Education\r\n2) Entertainment\r\n3) Grocery\r\n" +
								"4) Gas\r\n5) Bills\r\n6) Test \r\n7) Healthcare \r\n");
			dLine();
			System.out.print("Please enter a transaction type (Pick a Number): ");
			
		// user choice
			int transactionType = scan.nextInt();
			scan.nextLine();
			TransactionDAO tDAO = new TransactionDAO();
			List<Integer> totals = new ArrayList<Integer>();
			
			switch (transactionType) {
				case 1:
					totals = tDAO.getTotalByType("education");
					break;
				case 2:
					totals = tDAO.getTotalByType("entertainment");
					break;
				case 3:
					totals = tDAO.getTotalByType("grocery");
					break;
				case 4:
					totals = tDAO.getTotalByType("gas");
					break;
				case 5:
					totals = tDAO.getTotalByType("bills");
					break;
				case 6:
					totals = tDAO.getTotalByType("test");
					break;
				case 7:
					totals = tDAO.getTotalByType("healthcare");
					break;
			}
			newLine();
			
			// Print totals to console
			System.out.println("Here are the results:" +
								"\r\n\r\nTotal Count: " + totals.get(0) +
								"\r\nSum of Values: " + totals.get(1));
			
			// Ask to export to file
			newLine();
			System.out.print("Would you like to export the data to a file? (Y/N)");
			String decision = scan.next();
			dLine();
			decision.toLowerCase();
			if (decision.equals("y")) {
				exportIntListToTxtFile(totals);
			}
	}
	// -6-Total Count and Total Values for Branches in a State----------------------------
	public void runGetTotalByState() {
		// intro
		newLine();
		bLine();
		System.out.println("**Welcome to the Total Count and Total Values of Branches " + 
							"by State Section**");
		bLine();
		newLine();
		System.out.println("Please type in a standard state acronym of 2 characters\r\n" + 
							"(for example New York is NY)");
		System.out.print("Your choice: ");
		
		// user input
		String branchState = scan.next();
		newLine();
		TransactionDAO tDAO = new TransactionDAO();
		List<Integer> totals = new ArrayList<Integer>();
		totals = tDAO.getTotalByState(branchState);
		
		// Print totals to console
		System.out.println("Here are the results:" +
							"\r\n\r\nTotal Count: " + totals.get(0) +
							"\r\nSum of Values: " + totals.get(1));
		dLine();
		newLine();
		
		// Ask to export to file
		System.out.print("Would you like to export the data to a file? (Y/N)");
		String decision = scan.next();
		decision.toLowerCase();
		if (decision.equals("y")) {
			exportIntListToTxtFile(totals);
		}
	}
	// -7-Display Transactions between two dates------------------------------------------
	public void runTransBetweenDates() throws ParseException {
		// Intro
		newLine();
		bLine();
		System.out.println("*******Welcome to the Customer Transactions Between Two " + 
							"Dates Section*******");
		bLine();
		newLine();
		
		// User Input
		System.out.print("Please enter a Customer Social Security Number(SSN): ");
		int ssn = scan.nextInt();
		newLine();
		System.out.print("Please enter the first date in format YYYY-MM-DD\r\n" + 
							"(For example October 05, 2018 would be 2018-10-05)\r\n" + 
							"Date 1: ");
		String date1 = scan.next();
		newLine();
		System.out.print("Please enter the second date in format YYYY-MM-DD\r\n" + 
							"(For example October 05, 2018 would be 2018-10-05)\r\n" + 
							"Date 2: ");
		String date2 = scan.next();
		newLine();
		
		// Execute Transaction
		System.out.println("Here are the transaction results between " + date1 + 
							" and " + date2);
		List<Transaction> trans;
		CustomerDAO cDAO = new CustomerDAO();
		trans = cDAO.transBetweenDates(ssn, date1, date2);
		newLine();
		transFormat(trans);
		
		// Ask to export to file
		System.out.print("Would you like to export the data to a file? (Y/N)");
		String decision = scan.next();
		decision.toLowerCase();
		if (decision.equals("y")) {
			exportToTxtFile(trans);
		}
		
	}
// ------------------------------------------------------------------------------------------
// Formatters and Exports---------------------------------------------------------------------
// -Bill Table Formatter----------------------------------------------------------------------
	public void billFormat(List<Transaction> list) {
		String[] transFieldList = {
				"transaction_id", 
				"day", 
				"month", 
				"year", 
				"ssn", 
				"branchCode", 
				"creditCardNo", 
				"transactionType", 
				"transactionValue"
		};
		dLine();
	// Console print out
		System.out.format("%16s%8s%14s%19s%19s", transFieldList[0], transFieldList[1], 
							transFieldList[5],
							transFieldList[7],transFieldList[8]);
		System.out.println();
		dLine();
		for (Transaction x : list) {
			System.out.format("%16s%8s%14s%19s%19s", x.getTransaction_id(), x.getDay(), 
							x.getBranchCode(), x.getTransactionType(), 
							x.getTransactionValue() + "\r\n");
			//System.out.println(x.getTransaction_id());
			}
		dLine();
		newLine();
	}
// -Transaction Formatter-------------------------------------------------------
	public void transFormat(List<Transaction> list) {
		String[] transFieldList = {
				"transaction_id", 
				"day", 
				"month", 
				"year", 
				"ssn", 
				"branchCode", 
				"creditCardNo", 
				"transactionType", 
				"transactionValue"
		};
		dLine();
	// Console print out
		System.out.format("%-16s%-8s%-8s%-8s%-16s%-24s%-24s%-24s%-24s", transFieldList[0],
							transFieldList[1], transFieldList[2],
							transFieldList[3], transFieldList[4], transFieldList[5],
							transFieldList[6], 
							transFieldList[7], transFieldList[8]);
		System.out.println();
		superdLine();
		for (Transaction x : list) {
			System.out.format("%-16s%-8s%-8s%-8s%-16s%-24s%-24s%-24s%-24s", 
							x.getTransaction_id(), x.getDay(), x.getMonth(), 
							x.getYear(), x.getSsn(), x.getBranchCode(), 
							x.getCreditCardNo(), x.getTransactionType(),
							x.getTransactionValue());
			System.out.println();
			superdLine();
			}
		newLine();
	}
// -Export List of objects to a txt File--------------------------------------------------
	public void exportToTxtFile(List<Transaction> list) {
		File file = new File("Transactions.txt");
		try {
			FileWriter writer = new FileWriter(file);
			for (Transaction x : list) {
				String contents = x.toString();
				writer.write(contents);
				writer.write("\r\n");
//				System.out.println("These are the contents!!!");
//				System.out.println(contents);
			}
			writer.flush();
			writer.close();
			newLine();
			newLine();
			System.out.println("File successfully created as Transactions.txt!\r\n" + 
					"Remember to rename your file appropriately!");
			dLine();
			newLine();
		}
		catch (IOException e) {
			newLine();
			newLine();
			System.out.println("Failed to write to file!");
			newLine();
			newLine();
		}
	}
// -Export Object to Text File-------------------------------------------------------------
	public void exportCustObj2TxtFile(Customer cust) {
		File file = new File("Customer.txt");
		try {
			FileWriter writer = new FileWriter(file);
			writer.write(cust.getFirstName() + ",");
			writer.write(cust.getMiddleName() + ",");
			writer.write(cust.getLastName() + ",");
			writer.write(cust.getSsn() + ",");
			writer.write(cust.getCreditCardNo() + ",");
			writer.write(cust.getAptNo()+ ",");
			writer.write(cust.getStreetName() + ",");
			writer.write(cust.getCity() + ",");
			writer.write(cust.getState() + ",");
			writer.write(cust.getCountry() + ",");
			writer.write(cust.getZip() + ",");
			writer.write(cust.getPhone() + ",");
			writer.write(cust.getEmail());
			writer.flush();
			writer.close();
			newLine();
			newLine();
			System.out.println("File successfully created as Customer.txt!\r\n" + 
					"Remember to rename your file appropriately!");
			dLine();
			newLine();
		}
		catch (IOException e) {
			newLine();
			newLine();
			System.out.println("Failed to write to file!");
			newLine();
			newLine();
		}
	}
// -Export Integer List to Text File-------------------------------------------------------------
	private void exportIntListToTxtFile(List<Integer> totals) {
		File file = new File("Totals.txt");
		try {
			FileWriter writer = new FileWriter(file);
			writer.write("Total Sum: ");
			writer.write(String.valueOf(totals.get(0)));
			writer.write("\r\n");
			writer.write("Total Count: ");
			writer.write(String.valueOf(totals.get(1)));
			writer.flush();
			writer.close();
			newLine();
			newLine();
			System.out.println("File successfully created with the name Totals.txt!\r\n" + 
								"Remember to rename your file appropriately!");
			dLine();
			newLine();
			}
		catch (IOException e) {
			System.out.println("Failed to write to file!");
		}
	}
// -Aesthetic methods------------------------------------------------------------------------
	public void bLine() {
		System.out.println("*************************************************************" + 
							"***************");
	}
	public void dLine() {
		System.out.println("--------------------------------------------------------------" + 
							"--------------");
	}
	public void superdLine() {
		System.out.println("--------------------------------------------------------------" + 
							"-------------------------------------------------------------" + 
							"-----------------------------");
	}
// -New Line----------------------------------------------------------------------------------
	private static void newLine() {
		System.out.println();
	}
//-Errors-------------------------------------------------------------------------------------
// -Error sysouts------------------------------------------------------------------------
	public void errorLine() {
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + 
							"!!!!!!!!!!!!!!");
	}
	private void errorString() {
		newLine();
		errorLine();
		System.out.println("Please try again and use numbers!");
		errorLine();
	}
	private void errorSSN() {
		newLine();
		errorLine();
		System.out.println("Please try again and enter a valid 9 digit social security number!!");
		errorLine();
	}
	private void outOfRange() {
		newLine();
		errorLine();
		System.out.println("You have exited this section because your input was not from 1 to 11\r\n" + 
				"or you entered 0 to deliberately leave the section");
		errorLine();
	}
	private void not2DInt() {
		newLine();
		errorLine();
		System.out.println("Please try again and enter a valid 2 digit month!");
		errorLine();
		endSection();
	}
	private void not4DInt() {
		newLine();
		errorLine();
		System.out.println("Please try again and enter a valid 4 digit year!");
		errorLine();
		endSection();
	}
	private void endSection() {
		errorLine();
		System.out.println("Section has closed!");
		errorLine();
	}
	private void errorCCN() {
		newLine();
		errorLine();
		System.out.println("Please enter a valid 16 digit credit card number!");
		errorLine();
		
	}
// ----------------------------------------------------------------------------------------
	}