package com.cdw.resources;

public class Queries {
// Customer Details Module Queries----------------------------------------------------------------------------
	//-1------------------------------------------------------------------------------------------------------
	public final static String GET_CUSTOMER_BY_SSN = "SELECT * FROM CDW_SAPP_CUSTOMER WHERE ssn=?";
	//-2------------------------------------------------------------------------------------------------------
	// For modifying customer details-------------------------------------------------------------------------
	public final static String MODIFY_FIRST_NAME = "UPDATE CDW_SAPP_CUSTOMER SET FIRST_NAME=? WHERE SSN=?";
	public final static String MODIFY_MIDDLE_NAME = "UPDATE CDW_SAPP_CUSTOMER SET MIDDLE_NAME=? WHERE SSN=?";
	public final static String MODIFY_LAST_NAME = "UPDATE CDW_SAPP_CUSTOMER SET LAST_NAME=? WHERE SSN=?";
	//public final static String MODIFY_CREDIT_CARD = "UPDATE CDW_SAPP_CUSTOMER SET CREDIT_CARD_NO=? WHERE SSN=?";
	public final static String MODIFY_APT_NO = "UPDATE CDW_SAPP_CUSTOMER SET APT_NO=? WHERE SSN=?";
	public final static String MODIFY_STREET_NAME = "UPDATE CDW_SAPP_CUSTOMER SET STREET_NAME=? WHERE SSN=?";
	public final static String MODIFY_CUST_CITY = "UPDATE CDW_SAPP_CUSTOMER SET CUST_CITY=? WHERE SSN=?";
	public final static String MODIFY_CUST_STATE = "UPDATE CDW_SAPP_CUSTOMER SET CUST_STATE=? WHERE SSN=?";
	public final static String MODIFY_CUST_COUNTRY = "UPDATE CDW_SAPP_CUSTOMER SET CUST_COUNTRY=? WHERE SSN=?";
	public final static String MODIFY_CUST_ZIP = "UPDATE CDW_SAPP_CUSTOMER SET CUST_ZIP=? WHERE SSN=?";
	public final static String MODIFY_CUST_PHONE = "UPDATE CDW_SAPP_CUSTOMER SET CUST_PHONE=? WHERE SSN=?";
	public final static String MODIFY_CUST_EMAIL = "UPDATE CDW_SAPP_CUSTOMER SET CUST_EMAIL=? WHERE SSN=?";
	//-3------------------------------------------------------------------------------------------------------
	public final static String GET_MONTHLY_BILL = "SELECT TRANSACTION_ID, DAY, MONTH, YEAR, " +
								"CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE " +
								"FROM CDW_SAPP_CREDITCARD WHERE CREDIT_CARD_NO=? AND MONTH=? AND YEAR=?";
// -----------------------------------------------------------------------------------------------------------
// Transaction Details Module Queries-------------------------------------------------------------------------
	//-1------------------------------------------------------------------------------------------------------
	public final static String TRANSACTION_BY_ZIP_M_Y = "SELECT TRANSACTION_ID, DAY, MONTH, YEAR, " +
								"CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE " +
								"FROM CDW_SAPP_CUSTOMER C JOIN " + 
								"CDW_SAPP_CREDITCARD T USING(CREDIT_CARD_NO) WHERE C.CUST_ZIP=? AND MONTH=? " + 
								"AND YEAR=? ORDER BY C.CUST_ZIP, T.MONTH, T.YEAR, T.DAY DESC";
	//-2------------------------------------------------------------------------------------------------------
	public final static String TOTAL_BY_TYPE = "SELECT SUM(TRANSACTION_VALUE), COUNT(TRANSACTION_VALUE) FROM " + 
								"CDW_SAPP_CREDITCARD WHERE TRANSACTION_TYPE=?";
	//-3------------------------------------------------------------------------------------------------------
	public final static String TOTAL_BY_STATE = "SELECT SUM(TRANSACTION_VALUE), COUNT(TRANSACTION_VALUE) " +
								"FROM CDW_SAPP_CREDITCARD JOIN cdw_sapp_branch USING (BRANCH_CODE) WHERE " +
								"BRANCH_STATE=?";
	public static final String TRANS_BETWEEN_DATES = "SELECT TRANSACTION_ID, DAY, MONTH, YEAR, " +
								"CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, " + 
								"TRANSACTION_VALUE FROM CDW_SAPP_CREDITCARD WHERE CUST_SSN=? AND " +
								"str_to_date(CONCAT(YEAR,'-',LPAD(MONTH,2,'00'),'-',LPAD(DAY,2,'00')), '%Y-%m-%d') " +
								"BETWEEN ? AND ? ORDER BY YEAR DESC, MONTH DESC, DAY DESC";
// -----------------------------------------------------------------------------------------------------------
	// To prevent new instances of queries w/constructor
	private Queries() {
	}
}
